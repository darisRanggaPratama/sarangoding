public class ContohString {
    public static void main (String[] args) {
        System.out.println("\"Andromeda\", jawabnya." );
        System.out.println("Andi berujar, \"Bukan.\"");
    }
}    
        