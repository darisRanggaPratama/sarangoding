public class SistemBilangan {
    public static void main (String[] args) {
        int bil = 241;

        System.out.printf("Desimal     : %d\n", bil);
        System.out.printf("Oktal       : %o\n", bil);
        System.out.printf("Heksadesimal: %x\n", bil);
        System.out.printf("Heksadesimal: %X\n", bil);
    }
}    
        