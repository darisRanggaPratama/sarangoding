public class Pecahan {
    public static void main (String[] args) {
        double harga = 123.456;

        System.out.println(harga);
        System.out.printf("%.2f\n", harga);
        System.out.printf("%.3f\n", harga);
        System.out.printf("%.4f\n", harga);
        System.out.printf("%.5f\n", harga);
        System.out.printf("%.6f\n", harga);
        System.out.printf("%12.6f\n", harga);
    }
}    
        