public class ContohKarakter {
    public static void main (String[] args) {
        System.out.println('@');
        System.out.println('\u0040');
        System.out.println('\u2588');
    }
}    
        