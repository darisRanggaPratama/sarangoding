public class Konstan {
    public static void main (String[] args) {
        System.out.println("0x2B    = " + 0x2B);
        System.out.println("023     = " + 023);
        System.out.println("0b11010 = " + 0b11010);
        System.out.println("23      = " + 23);
    }
}    
        