public class LebarKeluaran {
    public static void main (String[] args) {
        String namaBarang = "Buku Tulis AAA 30lbr";
        int harga = 21750;

        System.out.printf("%8d\n", harga);
        System.out.printf("%9d\n", harga);
        System.out.printf("%10d\n", harga);
        System.out.printf("%11d\n", harga);
    }
}    
        