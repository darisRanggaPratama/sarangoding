public class Penugasan {
    public static void main (String[] args) {
        int x;
        
        x = 34;
        System.out.println("Nilai x semula  : " + x);

        x = 45;
        System.out.println("Nilai x sekarang: " + x);
    }
}    
        