public class KonversiEksplisit {
    public static void main (String[] args) {
        float hasilUjian;
        int hasilBulat;
        
        hasilUjian = 78.6f;
        hasilBulat = (int) hasilUjian;
        System.out.println(hasilBulat);
    }
}    
        