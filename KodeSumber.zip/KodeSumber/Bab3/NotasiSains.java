public class NotasiSains {
    public static void main (String[] args) {
        double data = 10.23456789;

        System.out.println(data);
        System.out.printf("%.2f\n", data);
        System.out.printf("%.2e\n", data);
        System.out.printf("%.2E\n", data);
    }
}    
        