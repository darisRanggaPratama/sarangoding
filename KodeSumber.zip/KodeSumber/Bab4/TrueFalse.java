// Penyajian nilai true dan false

public class TrueFalse {
    public static void main (String[] args) {
        System.out.println("Nilai true dan false");
        System.out.println("--------------------");

        System.out.println("Nilai true  = " + true );
        System.out.println("Nilai false = " + false );
    }
}    
        