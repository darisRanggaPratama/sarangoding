// Efek indeks 

public class EfekIndeks {
    public static void main (String[] args) {
        // Inisialisasi larik berdimensi satu

        int[] data = {50, 77, 30, 1, 22};

        System.out.println("Setelah larik diinisialisasi");

        // Pengubahan yang salah indeks
        data[5] = 61;

        System.out.println("*****");
    }
}    
        