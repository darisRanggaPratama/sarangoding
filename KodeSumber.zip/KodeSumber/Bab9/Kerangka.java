// Penyusunan program berdasarkan sejumlah metode

public class Kerangka {
    public static void main (String[] args) {
        masukan();
        proses();
        keluaran();
    }

    public static void masukan() {
    }

    public static void proses() {
    }

    public static void keluaran() {
    }
}    
        