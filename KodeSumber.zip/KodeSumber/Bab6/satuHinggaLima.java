// Penyajian angka 1 hingga 5
//    menggunakan do-while

public class SatuHinggaLima {
    public static void main (String[] args) {
        int bilangan;

        bilangan = 1;
        do {
            System.out.println(bilangan);

            bilangan = bilangan + 1;
        } while (bilangan <= 5);
    }
}    
        