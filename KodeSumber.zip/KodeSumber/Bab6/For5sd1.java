// Penyajian angka 5 hingga 1
//    menggunakan for

public class For5sd1 {
    public static void main (String[] args) {
        for (int bilangan = 5; bilangan >= 1; bilangan--)
            System.out.println(bilangan);
    }
}    
        