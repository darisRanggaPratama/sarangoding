// Penyajian angka 1 hingga 5
//    menggunakan while

public class While5sd1 {
    public static void main (String[] args) {
        int bilangan;

        bilangan = 5;
        while (bilangan >= 1) {
            System.out.println(bilangan);

            bilangan = bilangan - 1;
        }
    }
}    
        