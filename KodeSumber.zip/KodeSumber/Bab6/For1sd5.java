// Penyajian angka 1 hingga 5
//    menggunakan for

public class For1sd5 {
    public static void main (String[] args) {
        for (int bilangan = 1; bilangan <= 5; bilangan++)
            System.out.println(bilangan);
    }
}    
        