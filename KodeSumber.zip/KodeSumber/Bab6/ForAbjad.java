// Penyajian huruf A hingga Z
//    menggunakan for

public class ForAbjad {
    public static void main (String[] args) {
        for (char huruf = 'A'; huruf <= 'Z'; huruf++)
            System.out.print(huruf + " ");

        System.out.println(); // Pindah baris
    }
}    
        