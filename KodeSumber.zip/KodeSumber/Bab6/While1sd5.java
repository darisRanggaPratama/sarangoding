// Penyajian angka 1 hingga 5
//    menggunakan while

public class While1sd5 {
    public static void main (String[] args) {
        int bilangan;

        bilangan = 1;
        while (bilangan <= 5) {
            System.out.println(bilangan);

            bilangan = bilangan + 1;
        }
    }
}    
        