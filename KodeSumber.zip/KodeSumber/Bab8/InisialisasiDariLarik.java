// Inisialisasi string dari larik karakter

import java.util.Scanner;

public class InisialisasiDariLarik {
    public static void main (String[] args) {
        char [] daftarKar = {'M', 'e', 'r', 'a', 'k'};
        String namaBurung = new String(daftarKar);

        System.out.println("namaBurung: " + namaBurung);
    }
}    
        