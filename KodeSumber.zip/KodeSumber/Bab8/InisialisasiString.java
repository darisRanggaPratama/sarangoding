// Inisialisasi string

import java.util.Scanner;

public class InisialisasiString {
    public static void main (String[] args) {
        String namaHewan = new String("Kelinci");
        String namaBurung = "Kutilang";

        System.out.println("namaHewan: " + namaHewan);
        System.out.println("namaBurung: " + namaBurung);
    }
}    
        