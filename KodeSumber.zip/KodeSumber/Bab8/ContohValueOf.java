// Contoh valueOf()

public class ContohValueOf {
    public static void main (String[] args) {
        System.out.println("Metode valueOf()");
        System.out.println("----------------");

        String teks = "";
        teks = teks.valueOf(123);
        System.out.println("Isi teks: " + teks);
    }
}    
        