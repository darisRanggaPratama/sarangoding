// Cara untuk mendapatkan cacah karakter
//     pada string

public class PanjangString {
    public static void main (String[] args) {
        String stringA = "";
        String stringB = "B";
        String stringC = "Dua kata";
        
        System.out.println("Jumlah karakter pada stringA: " +
                           stringA.length());
        System.out.println("Jumlah karakter pada stringB: " +
                           stringB.length());
        System.out.println("Jumlah karakter pada stringC: " +
                           stringC.length());
    }
}    
        