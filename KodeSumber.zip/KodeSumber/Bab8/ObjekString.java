// Objek string

import java.util.Scanner;

public class ObjekString {
    public static void main (String[] args) {
        String namaBurung;
        namaBurung = "Kutilang";

        System.out.println("namaBurung: " + namaBurung);
    }
}    
        