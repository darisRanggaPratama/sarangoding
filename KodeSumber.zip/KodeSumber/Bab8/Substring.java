// Contoh penggunaan substring()

public class Substring {
    public static void main (String[] args) {
        System.out.println("Metode substring()");
        System.out.println("------------------");

        String teks = "Sukses";
        for (int i = 0; i < teks.length(); i++)
            System.out.println(teks.substring(i));
    }
}    
        