// Contoh pengabungan string dengan concat()

public class PenggabunganString2 {
    public static void main (String[] args) {
        System.out.println("Penggabungan string");
        System.out.println("-------------------");

        String kataA = "Bulan";
        String kataB = "Bintang";

        String hasil = kataA.concat(kataB);

        System.out.println("Hasil concat(): " + hasil);
    }
}    
        