// Contoh penggunaan assert

import java.util.Scanner;

public class ContohAssert {
    public static void main(String[] args) {
        Scanner kbd = new Scanner(System.in);

        System.out.print("Usia anda: ");
        int usia = kbd.nextInt();

        assert usia >= 17: "Belum cukup usia";

        System.out.println("Usia Anda " + usia);
    }
}

